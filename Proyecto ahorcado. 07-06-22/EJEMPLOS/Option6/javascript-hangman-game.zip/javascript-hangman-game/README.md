# JavaScript Hangman game

A Pen created on CodePen.io. Original URL: [https://codepen.io/cathydutton/pen/ldazc](https://codepen.io/cathydutton/pen/ldazc).

A JavaScript Hangman game with canvas animatoin.